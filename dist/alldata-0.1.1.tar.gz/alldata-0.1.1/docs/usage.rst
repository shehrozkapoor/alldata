=====
Usage
=====

To use alldata in a project::

	import alldata
